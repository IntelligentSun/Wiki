function [V E] = buildrrt(x, y, obsts, start, goal, max_vertices)
V = start';
E = [];
% TODO: implement
