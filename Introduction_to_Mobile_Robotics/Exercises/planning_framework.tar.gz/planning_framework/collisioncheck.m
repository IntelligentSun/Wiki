% checks a single vertice v (1x2) for collision with the
% obstacle cells obsts (2xm).
% Returns 1 for collision, 0 otherwise
function coll = collisioncheck(v, obsts)
coll = 0;
% TODO: implement
