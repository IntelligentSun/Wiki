% The function [X Y START GOAL OBSTS] = DEFINEENV returns
% a grid discretized environment described by the vectors X and Y
% that span the state space, a default START and GOAL (both 2x1
% vectors) and the obstacle list OBSTS that contains all blocked cells in
% the environment. OBSTS is a 2xn matrix with columns that correspond
% to the x,y-coordinates of all n obstacle cells.
%
% v.1.0, July 2011, koa

function [x y start goal obsts] = defineenv()

% Define state space
x = 1:19;
y = 1:16;
nx = length(x);
ny = length(y);

% Define obstacle cells
wall1 = 4:16;
obst1 = [wall1; repmat(7,1,length(wall1))];
wall2 = [2:4 8 9 13:16];
obst2 = [...
  7 7 14 14;...
  2 6 2 6
];
obst3 = [wall2; repmat(11,1,length(wall2))];
obst4 = [...
   4  4  4  4  8  8  8  8 14 14 14 14;...
  12 13 15 16 12 13 15 16 12 13 14 15 
];
wallbottom = [x; repmat(1,1,nx)];
walltop = [x; repmat(ny,1,nx)];
wallleft = [repmat(1,1,ny); y];
wallright = [repmat(nx,1,ny); y];
obst5 = [wallbottom walltop wallleft wallright];
obsts = [obst1 obst2 obst3 obst4 obst5];

% Define goal and start
goal = [3; 2];
start = [17; 15];