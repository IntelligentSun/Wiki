% checks whether the straight line connection
% between nodes v1 and v2 (1x2) is collision free
% given the obstacles obsts. Returns 1 if the
% connection is collision free, 0 otherwise.
function ok = localplanner(v1, v2, obsts)
ok = 1;
% TODO: implement
