function plotall(obsts, start, goal, V, E)
plotenv(obsts);
hold on;
plotgraph(V, E);
plotnode(start, 0.2, 'start', [.9 .1 .1]);
plotnode(goal, 0.2, 'goal', [.9 .1 .1]);
hold off;

