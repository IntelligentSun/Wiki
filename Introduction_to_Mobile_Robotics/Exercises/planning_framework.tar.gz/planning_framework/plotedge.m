%PLOTEDGE Illustrates a spatial relationship.
%   PLOTEDGE(XS,XE,SHAPE,LABEL,COLOR) draws a nice looking
%   curved arrow from location XS (3x1) to XE (3x1) and labels
%   it with LABEL (Matlab text syntax). COLOR is a [r g b]-vector
%   or a Matlab color string such as 'r' or 'g'. SHAPE controls
%   the shape of the curve: '/' for a S-shape, '\' for a Z-shape,
%   '(' for a left arc and ')' for a right arc.
%
%   H = PLOTEDGE(...) returns a column vector of handles to
%   all graphic objects of the drawing. Remember that not all
%   graphic properties apply to all types of graphic objects.
%
%   See also PLOTNODE, PLOT.


function h = plotedge(x1,x2,shape,label,color,offset,arrow)

% Constants
FILLED = 1;           % filled arrow head by default
ASIZE  = 0.1;         % default arrow head size
NPTS   = 50;          % number of points for the spline
TPFRAC = 0.2;         % fractional dist. of tangential points
TPADEV = pi/50;       % angle deviation of tang. points from phi
NPOINTS = 50;         % Nr of points for self-reference circle

if x1 == x2,
  % Draw circle for self-edge
  ivec = 0:2*pi/NPOINTS:2*pi;
  p(1,:) = 3*offset*cos(ivec)/4 + x1(1) + offset;
  p(2,:) = 3*offset*sin(ivec)/4 + x1(2);
  %xt = x1(1) + 2*offset; yt = x1(2);
  ilabel = ceil(size(p,2)/2);
  xt = p(1,ilabel) + offset;
  yt = p(2,ilabel) + offset;
  tt = -pi/4;
else
  % Draw spline
  xs  = x1(1); ys = x1(2);      % orientation not used
  xe  = x2(1); ye = x2(2);      % orientation not used
  phi = atan2(ye-ys, xe-xs);
  d   = norm([ye-ys, xe-xs]);
  xs = xs + offset*cos(phi);
  ys = ys + offset*sin(phi);
  xe = xe - offset*cos(phi);
  ye = ye - offset*sin(phi);
  if shape == '|',
    p = [xs xe; ys ye];
  else
    switch shape
      case '/',
        xst = xs + d*TPFRAC*cos(phi+TPADEV);
        yst = ys + d*TPFRAC*sin(phi+TPADEV);
        xet = xe - d*TPFRAC*cos(phi+TPADEV);
        yet = ye - d*TPFRAC*sin(phi+TPADEV);
      case '\',
        xst = xs + d*TPFRAC*cos(phi-TPADEV);
        yst = ys + d*TPFRAC*sin(phi-TPADEV);
        xet = xe - d*TPFRAC*cos(phi-TPADEV);
        yet = ye - d*TPFRAC*sin(phi-TPADEV);
      case '(',
        xst = xs + d*TPFRAC*cos(phi+TPADEV);
        yst = ys + d*TPFRAC*sin(phi+TPADEV);
        xet = xe - d*TPFRAC*cos(phi-TPADEV);
        yet = ye - d*TPFRAC*sin(phi-TPADEV);
      case ')',
        xst = xs + d*TPFRAC*cos(phi-TPADEV);
        yst = ys + d*TPFRAC*sin(phi-TPADEV);
        xet = xe - d*TPFRAC*cos(phi+TPADEV);
        yet = ye - d*TPFRAC*sin(phi+TPADEV);
      otherwise
        error('drawtransform: Unsupported shape');
    end;
    % Turn to k*45 deg since spline must have distinct values in x,y
    p  = [xs xst xet xe; ys yst yet ye];
    R  = [cos(pi/4-phi) -sin(pi/4-phi); sin(pi/4-phi) cos(pi/4-phi)];
    p  = R*p;
    xx = min(p(1,:)):(max(p(1,:))-min(p(1,:)))/NPTS:max(p(1,:));
    yy = spline(p(1,:),p(2,:),xx);
    p  = inv(R)*[xx; yy];
  end;
  ilabel = ceil(1*size(p,2)/10);
  xt = p(1,ilabel);
  yt = p(2,ilabel);
end;

% Plot transform
hp = plot(p(1,:),p(2,:),'-','Color',color);

% Display text
if ~isempty(label),
  ht = text(xt,yt,label,'Color',color,'VerticalAlignment','middle','HorizontalAlignment','left');
  %ht = drawlabel([xt yt tt],label,0.15,0.07,'k');
else
  ht = [];
end;

% Draw arrow head
if arrow,
  ha = drawarrow(p(1:2,end-2),p(1:2,end),FILLED,ASIZE,color);
  h = cat(2,hp,ht,ha);
else
  h = cat(2,hp,ht);
end;

