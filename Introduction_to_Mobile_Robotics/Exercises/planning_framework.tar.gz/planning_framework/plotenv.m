function plotenv(obsts)

figure(1); clf;
obstc = repmat(obsts,4,1) + repmat([-.5 -.5 .5 -.5 .5 .5 -.5 .5]',1,size(obsts,2));
fill(obstc(1:2:end,:),obstc(2:2:end,:),[.53 .58 .47]);
set(gca,'XTick',[],'YTick',[]);
axis equal; axis tight;
