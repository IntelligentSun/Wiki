% The function plotgraph plots the graph defined
% by the vertices V and the edges E.
% V is a (nx2) matrix where each row vector contains the
% x and y coordinate of a vertice.
% E is a (mx2) matrix where each row vector contains the
% position (row index) of two vertices in V connected by this edge.

function [hnodes hedges] = plotgraph(V, E)

% Parameters
LW = 1;
COL = [.9 .1 .1];
SIZE = 0.1;

% Plot edges
hedges = [];
for i = 1:size(E,1),
  x1 = [V(E(i,1),:) 0];
  x2 = [V(E(i,2),:) 0];
  h = plotedge(x1',x2','|','',[.3 .3 .3],SIZE,0);
  set(h(1),'LineWidth',LW);
  hedges = cat(1,hedges,h);
end;

% Plot vertices
hnodes = [];
for i = 1:size(V,1),
  h = plotnode(V(i,:)',SIZE,'',COL);
  set(h,'LineWidth',LW);
  hnodes = cat(1,hnodes,h);
end;


