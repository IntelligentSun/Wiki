%PLOTNODE   Plot node for a graphical model visualization
%   PLOTNODE(X,S,LABEL,COLOR) plots a circular node at X = [x; y] of size S
%   with label string LABEL with background color COLOR.

function h = plotnode(x,s,label,color)

% Constants
NPOINTS = 16;                        % point density or resolution

% Plot circle
ivec = linspace(0,2*pi,NPOINTS+1);   % index vector
p(1,:) = s*cos(ivec) + x(1);         % 2 x n matrix which
p(2,:) = s*sin(ivec) + x(2);         % hold ellipse points

% Plot border and fill
hfill   = patch(p(1,:),p(2,:),color);
hborder = plot(p(1,:),p(2,:),'k-');

% Plot label
if ischar(label),
  hlabel = text(x(1),x(2),label,'VerticalAlignment','middle','HorizontalAlignment','center',...
    'FontSize',9);
end;

h = cat(2,hborder,hfill,hlabel);