% samples num_points from the envionment. The range of the
% environment is defined by x and y. The obstacle cells are
% listed in obsts.
function V = rejectionsample(x, y, obsts, num_points)
V = [];
% TODO: implement
