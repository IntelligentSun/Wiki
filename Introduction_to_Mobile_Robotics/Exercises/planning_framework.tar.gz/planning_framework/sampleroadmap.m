% Samples a probabilistic roadmap with
% num_vertices in the environment.
% The range of the environment is defined by x and y.
% The obstacle cells are listed in obsts.
% Returns the sampled vertices and collision-free edges.
function [V E] = sampleroadmap(x, y, obsts, num_vertices)
LOCAL_DIST = 6;
V = [];
E = [];
% TODO: implement

