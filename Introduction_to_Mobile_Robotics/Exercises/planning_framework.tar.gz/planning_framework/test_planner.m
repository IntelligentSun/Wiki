% Exercise frame
% Define environment
[x y start goal obsts] = defineenv;

%% Example
% define graph (according to documentation in plotgraph.m)
V = [2.5 3.1; 2.4 9.1; 6.2 4.8; 10.4 4.4; 1.2 4.5; 7.1 5.9]
E = [1 2; 1 3; 1 4]

% Plot environment
plotall(obsts, start, goal, V, E);

pause;

%% Test collision check
disp('Testing collision check ...');
coll = zeros(size(V,1),1);
for i = 1:size(V,1),
  coll(i,1) = collisioncheck(V(i,:), obsts);
end;
disp('collisioncheck result:');
disp(coll');

pause;

%% Test local planner
disp('Testing local planner by trying to connect all available vertices ...');
E = [];
for i=1:size(V,1),
  for j=i+1:size(V,1),
    ok = localplanner(V(i,:), V(j,:), obsts);
    if (ok == 1),
      E = [E; [i j]];
    end;
  end;
end;
disp(['number of possible edges is: ' num2str(size(E,1))]);
plotall(obsts, start, goal, V, E);

pause;

%% Test rejection sampling
disp('Testing rejection sampling ...');
V = rejectionsample(x, y, obsts, 20);
disp(['sampled ' num2str(size(V,1)) ' collision-free vertices']);
plotall(obsts, start, goal, V, []);

pause;

%% Test sampling of roadmap
disp('Testing sampling of roadmap ...');
[V E] = sampleroadmap(x, y, obsts, 20);
disp(['sampled roadmap with ' num2str(size(V,1)) ' vertices']);
plotall(obsts, start, goal, V, E);

pause;

%% Test RRT planner
disp('Testing RRT planner ...');
[V E] = buildrrt(x, y, obsts, start, goal, 200);
plotall(obsts, start, goal, V, E);

