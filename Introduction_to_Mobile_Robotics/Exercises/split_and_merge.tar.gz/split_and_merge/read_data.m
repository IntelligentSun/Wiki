function data = read_data(filename)
    data = [];
    input = fopen(filename);
    while(!feof(input))
        line = fgetl(input);
        arr = char(strsplit(line, ' '));
        type = deblank(arr(1,:));

	    data(end+1,:) = [str2num(arr(1,:)), str2num(arr(2,:))];
    endwhile
    fclose(input);
end
