function points = split_and_merge(data)
    % Performs the split and merge algorihtm on the provided data.
    %
    % - data matrix of the dimensions N x 2, where N is the number of the data
    %   points
    % - points matrix of the dimensions #points x 2, containing the list of
    %   start, break, and end points
 
    % TODO: Ex 1 a - implement
end
