data = read_data('laser_scan_1.dat');
%data = read_data('laser_scan_2.dat');

points_1 = split_and_merge(data);

hold('off');
plot(data(:,1),data(:,2), 'o');
hold('on');
plot(points_1(:,1), points_1(:,2), '-r');
